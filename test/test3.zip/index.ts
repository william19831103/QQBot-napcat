import { NCWebsocketApi } from '../src/NCWebsocketApi'
import dotenv from 'dotenv'
import fetch from 'node-fetch'
import * as fs from 'fs'
import * as path from 'path'
import { fileURLToPath } from 'url'
import { spawn } from 'child_process'

// 获取当前文件的目录路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 加载环境变量
dotenv.config()

// 创建图片保存目录
const SAVE_DIR = path.join(__dirname, 'received_images')
if (!fs.existsSync(SAVE_DIR)) {
  fs.mkdirSync(SAVE_DIR, { recursive: true })
}

// OCR文字识别函数
async function ocrImage(imagePath: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const pythonProcess = spawn('python', [
      path.join(__dirname, 'TextOcr.py'),
      '--image', imagePath,
      '--api_key', process.env.OCR_API_KEY || 'K87108387888957'
    ], {
      env: { ...process.env, PYTHONIOENCODING: 'utf-8' }
    })

    let result = ''
    let error = ''

    pythonProcess.stdout.on('data', (data) => {
      result += data.toString('utf-8')
    })

    pythonProcess.stderr.on('data', (data) => {
      // 输出调试信息
      console.log('Python调试信息:', data.toString('utf-8'))
      error += data.toString('utf-8')
    })

    pythonProcess.on('close', (code) => {
      if (code !== 0) {
        reject(new Error(`Python进程退出，错误码：${code}\n${error}`))
      } else {
        try {
          console.log('Python输出原始数据:', result.trim()) // 调试输出
          const jsonResult = JSON.parse(result.trim())
          if (jsonResult.error) {
            reject(new Error(jsonResult.error))
          } else {
            resolve(jsonResult.text)
          }
        } catch (e) {
          reject(new Error(`解析OCR结果失败：${e}\n原始数据：${result}`))
        }
      }
    })
  })
}

async function saveImage(url: string, filename: string): Promise<string> {
  const response = await fetch(url)
  const arrayBuffer = await response.arrayBuffer()
  const buffer = Buffer.from(arrayBuffer)
  const savePath = path.join(SAVE_DIR, filename)
  fs.writeFileSync(savePath, buffer)
  return savePath
}

async function main() {
  const api = new NCWebsocketApi({
    protocol: 'ws',
    host: process.env.WS_HOST ?? '',
    port: Number(process.env.WS_PORT),
    accessToken: process.env.ACCESS_TOKEN
  })

  // 连接成功事件
  api.on('meta_event', event => {
    if (event.meta_event_type === 'lifecycle') {
      console.log('连接成功！')
    }
  })

  // 接收消息事件
  api.on('message', async event => {
    console.log('收到消息：', event)
    
    if (event.message_type === 'private') {
      // 检查是否是图片消息
      if (event.message[0]?.type === 'image') {
        const imageData = event.message[0].data
        const imageUrl = imageData.url
        const fileName = imageData.file
        const fileId = imageData.file_id
        const fileUnique = imageData.file_unique
        
        try {
          // 保存图片
          const timestamp = new Date().getTime()
          const saveFileName = `${timestamp}_${fileUnique}.png`
          const savePath = await saveImage(imageUrl, saveFileName)
          
          // 进行OCR识别
          const ocrResult = await ocrImage(savePath)
          
          // 回复消息
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: `我收到了你的图片：\n` +
                        `原始文件名：${fileName}\n` +
                        `文件ID：${fileId}\n` +
                        `文件唯一标识：${fileUnique}\n` +
                        `已保存到：${savePath}\n\n` +
                        `OCR识别结果：\n${ocrResult}\n\n` +
                        `这是你发送的图片：\n`
                }
              },
              {
                type: 'image',
                data: {
                  file: imageUrl
                }
              }
            ]
          })
        } catch (error) {
          console.error('处理图片失败：', error)
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: '处理图片时发生错��！'
                }
              }
            ]
          })
        }
      } else {
        // 普通文本消息回复
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '收到你的消息了，宣传码是：R2DPTZ7Rz，每日一次，多了无效'
              }
            }
          ]
        })
      }
    }
    
    // 如果是群消息
    if (event.message_type === 'group') {
      await api.send_group_msg({
        group_id: event.group_id,
        message: [
          {
            type: 'text',
            data: {
              text: '收到你的群消息了！'
            }
          }
        ]
      })
    }
  })

  // 连接
  await api.connect()
}

main().catch(console.error)
