import requests
import argparse
import json
import sys

# 设置标准输出编码为UTF-8
sys.stdout.reconfigure(encoding='utf-8')

def ocr_image(image_path, api_key):
    """
    使用 OCR.space API 识别图片中的文字
    """
    url = "https://api.ocr.space/parse/image"
    
    # 准备文件和参数
    files = {
        'file': open(image_path, 'rb')
    }
    
    headers = {
        'apikey': api_key,
    }
    
    payload = {
        'language': 'chs',  # 支持中文识别
        'isOverlayRequired': True,
        'detectOrientation': True,
        'OCREngine': 2,  # 使用更准确的OCR引擎
        'scale': True,
        'detectCheckbox': False,
    }
    
    try:
        response = requests.post(url, headers=headers, files=files, data=payload)
        print(f"DEBUG: API响应状态码: {response.status_code}", file=sys.stderr)
        
        if response.status_code == 200:
            result = response.json()
            print(f"DEBUG: API原始响应: {result}", file=sys.stderr)
            
            if result["OCRExitCode"] == 1:
                parsed_text = result["ParsedResults"][0]["ParsedText"]
                print(f"DEBUG: 识别文本: {parsed_text}", file=sys.stderr)
                
                # 使用UTF-8编码输出JSON结果
                result_json = json.dumps(
                    {"text": parsed_text}, 
                    ensure_ascii=False, 
                    indent=2
                )
                print(result_json)
                return
        
        print(json.dumps({"error": "OCR识别失败"}, ensure_ascii=False))
            
    except Exception as e:
        print(json.dumps({"error": f"OCR识别错误：{str(e)}"}, ensure_ascii=False))

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='OCR图片识别')
    parser.add_argument('--image', required=True, help='图片路径')
    parser.add_argument('--api_key', required=True, help='OCR.space API密钥')
    
    args = parser.parse_args()
    ocr_image(args.image, args.api_key)
