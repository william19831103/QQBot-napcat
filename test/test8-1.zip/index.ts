import { NCWebsocketApi } from '../src/NCWebsocketApi'
import dotenv from 'dotenv'
import fetch from 'node-fetch'
import * as fs from 'fs'
import * as path from 'path'
import { fileURLToPath } from 'url'
import { spawn } from 'child_process'
import { tmpdir } from 'os'
import { OCRKeyManager } from './OCRKeyManager'
import { CDKeyManager } from './CDKeyManager'
import { CooldownManager } from './CooldownManager'
import { KeywordDetector } from './KeywordDetector'

// 获取当前文件的目录路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 加载环境变量和关键词配置
dotenv.config()
const matchConfig = JSON.parse(fs.readFileSync(path.join(__dirname, 'MatchString.json'), 'utf-8'))

// 初始化 OCR Key 管理器
const ocrKeyManager = new OCRKeyManager([
  'K87108387888957',
  'K89499185488957',
  'K82081561288957'
])

// 初始化 CDKey 管理器
const cdkeyManager = new CDKeyManager()

// 初始化冷却管理器（10秒冷却时间）
const cooldownManager = new CooldownManager(10)

// 初始化关键词检测器
const groupKeywordDetector = new KeywordDetector(path.join(__dirname, 'adwords.json'))

// 检查文本匹配度
function checkTextMatch(text: string): {
  isMatch: boolean,
  matchedWords: string[],
  matchCount: number
} {
  const matchedWords = matchConfig.keywords.filter(keyword => 
    text.includes(keyword)
  )

  return {
    isMatch: matchedWords.length >= 3, // 匹配3个或以上关键词
    matchedWords,
    matchCount: matchedWords.length
  }
}

// OCR文字识别函数
async function ocrImage(imageUrl: string): Promise<string> {
  const tempFile = path.join(tmpdir(), `ocr_temp_${Date.now()}.png`)
  
  try {
    const response = await fetch(imageUrl)
    const arrayBuffer = await response.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)
    fs.writeFileSync(tempFile, buffer)
    
    const apiKey = ocrKeyManager.getCurrentKey()
    
    return new Promise((resolve, reject) => {
      const pythonProcess = spawn('python', [
        path.join(__dirname, 'TextOcr.py'),
        '--image', tempFile,
        '--api_key', apiKey
      ], {
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' }
      })

      let result = ''

      pythonProcess.stdout.on('data', (data) => {
        result += data.toString('utf-8')
      })

      pythonProcess.on('close', (code) => {
        try {
          fs.unlinkSync(tempFile)
        } catch (e) {
          console.error('删除临时文件失败:', e)
        }

        if (code !== 0) {
          reject(new Error('OCR识别失败'))
        } else {
          try {
            const jsonResult = JSON.parse(result.trim())
            if (jsonResult.error) {
              reject(new Error(jsonResult.error))
            } else {
              resolve(jsonResult.text)
            }
          } catch (e) {
            reject(new Error('解析OCR结果失败'))
          }
        }
      })
    })
  } catch (error) {
    if (fs.existsSync(tempFile)) {
      fs.unlinkSync(tempFile)
    }
    throw error
  }
}

async function main() {
  const api = new NCWebsocketApi({
    protocol: 'ws',
    host: process.env.WS_HOST ?? '',
    port: Number(process.env.WS_PORT),
    accessToken: process.env.ACCESS_TOKEN
  })

  api.on('meta_event', event => {
    if (event.meta_event_type === 'lifecycle') {
      console.log('连接成功！')
    }
  })

  api.on('message', async event => {
    console.log('收到消息：', event)
    
    // 检查消息是否为空
    if (!event.message || event.message.length === 0) {
      console.log('收到空消息，忽略处理')
      return
    }
    
    // 处理群消息
    if (event.message_type === 'group') {
      try {
        // 检查是否是图片消息
        if (event.message[0]?.type === 'image') {
          const imageUrl = event.message[0].data.url
          try {
            // 进行OCR识别
            const ocrResult = await ocrImage(imageUrl)
            console.log('群图片OCR结果:', ocrResult)

            // 检查OCR结果中是否包含关键词
            if (groupKeywordDetector.detect(ocrResult)) {
              const matchedKeywords = groupKeywordDetector.getMatchedKeywords(ocrResult)
              console.log('群图片匹配到的关键词:', matchedKeywords)

              try {
                // 先撤回消息
                await api.delete_msg({
                  message_id: event.message_id
                })
                console.log(`已撤回群 ${event.group_id} 中的图片消息`)

                // 再踢出发送者
                await api.set_group_kick({
                  group_id: event.group_id,
                  user_id: event.user_id,
                  reject_add_request: false
                })
                console.log(`已将用户 ${event.user_id} 踢出群 ${event.group_id}`)
              } catch (actionError) {
                console.error('执行撤回或踢人操作失败：', actionError)
              }
            }
          } catch (ocrError) {
            console.error('处理群图片OCR失败：', ocrError)
          }
        }

        // 检查文本消息中的关键词
        const messageText = event.raw_message || event.message.map(segment => {
          if (segment.type === 'text') {
            return segment.data.text
          }
          return ''
        }).join('')

        console.log('群消息内容:', messageText)

        // 检查关键词
        if (groupKeywordDetector.detect(messageText)) {
          const matchedKeywords = groupKeywordDetector.getMatchedKeywords(messageText)
          console.log('匹配到的关键词:', matchedKeywords)

          try {
            // 先撤回消息
            await api.delete_msg({
              message_id: event.message_id
            })
            console.log(`已撤回群 ${event.group_id} 中的消息: ${messageText}`)

            // 再踢出发送者
            await api.set_group_kick({
              group_id: event.group_id,
              user_id: event.user_id,
              reject_add_request: false
            })
            console.log(`已将用户 ${event.user_id} 踢出群 ${event.group_id}`)
          } catch (actionError) {
            console.error('执行撤回或踢人操作失败：', actionError)
          }
        }
      } catch (error) {
        console.error('处理群消息失败：', error)
      }
    }

    if (event.message_type === 'private') {
      // 检查是否是管理员命令
      if (event.message[0]?.type === 'text' && event.message[0].data.text === '/rl') {
        groupKeywordDetector.loadKeywords()
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: `关键词重载成功！\n当前关键词：${groupKeywordDetector.getCurrentKeywords().join(', ')}`
              }
            }
          ]
        })
        return
      }

      // 首先检查用户是否已经领取过 CDKey
      if (!cdkeyManager.canUserGetKey(event.user_id)) {
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '您今天已经领取过卡密了，每日一次，请明天再来！每日午夜12点刷新！'
              }
            }
          ]
        })
        return
      }

      // 检查是否还有可用的 CDKey
      if (cdkeyManager.getRemainingCount() === 0) {
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '抱歉，卡密已经发完了！请联系老G！'
              }
            }
          ]
        })
        return
      }

      // 用户未领取且有可用卡密，再进行图片识别
      try {
        const imageUrl = event.message[0].data.url
        const ocrResult = await ocrImage(imageUrl)
        const matchResult = checkTextMatch(ocrResult)
        
        if (matchResult.isMatch) {
          // 获取新的 CDKey
          const cdkey = cdkeyManager.getNewKey(event.user_id)
          
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: `验证成功！\n` +
                        // `匹配到 ${matchResult.matchCount} 个关键词：${matchResult.matchedWords.join(', ')}\n` +
                        `您的卡密是：${cdkey}\n` +
                        `剩余卡密数量：${cdkeyManager.getRemainingCount()}\n` +
                        `使用说明：请在游戏内，使用宣传手册，点击兑换卡密领取奖励！`
                }
              }
            ]
          })
        } else {
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: '图片识别失败，请发送文字清晰的截图！'
                }
              }
            ]
          })
        }
      } catch (error) {
        console.error('处理图片失败：', error)
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '图片识别失败，请发送文字清晰的截图！'
              }
            }
          ]
        })
      }
    }
  })

  await api.connect()
}

main().catch(console.error)
