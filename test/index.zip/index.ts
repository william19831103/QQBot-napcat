import { NCWebsocketApi } from '../src/NCWebsocketApi'
import dotenv from 'dotenv'
import * as tf from '@tensorflow/tfjs-node'
import fetch from 'node-fetch'

// 加载环境变量
dotenv.config()

// 加载预训练模型
const loadModel = async () => {
  // 使用MobileNet预训练模型
  const model = await tf.loadLayersModel(
    'https://storage.googleapis.com/tfjs-models/tfjs/mobilenet_v1_0.25_224/model.json'
  )
  return model
}

// 图像识别函数
async function detectImage(imageUrl: string) {
  try {
    const model = await loadModel()
    
    // 下载图片
    const response = await fetch(imageUrl)
    const buffer = await response.buffer()
    
    // 转换图片为tensor
    const tensor = tf.node.decodeImage(buffer)
    const resized = tf.image.resizeBilinear(tensor, [224, 224])
    const expanded = resized.expandDims(0)
    const normalized = expanded.div(255.0)
    
    // 预测
    const predictions = await model.predict(normalized).data()
    
    // 释放内存
    tensor.dispose()
    resized.dispose()
    expanded.dispose()
    normalized.dispose()
    
    return predictions
  } catch (error) {
    console.error('图像识别错误:', error)
    return null
  }
}

async function main() {
  const api = new NCWebsocketApi({
    protocol: 'ws',
    host: process.env.WS_HOST ?? '',
    port: Number(process.env.WS_PORT),
    accessToken: process.env.ACCESS_TOKEN
  })

  // 连接成功事件
  api.on('meta_event', event => {
    if (event.meta_event_type === 'lifecycle') {
      console.log('连接成功！')
    }
  })

  // 接收消息事件
  api.on('message', async event => {
    console.log('收到消息：', event)
    
    if (event.message_type === 'private') {
      // 检查是否是图片消息
      if (event.message[0]?.type === 'image') {
        const imageUrl = event.message[0].data.url
        // 回复相同的图片
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '我收到了你的图片，这是同样的图片：\n'
              }
            },
            {
              type: 'image',
              data: {
                file: imageUrl
              }
            }
          ]
        })
      } else {
        // 普通文本消息回复
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '收到你的消息了，宣传码是：R2DPTZ7Rz，每日一次，多了无效'
              }
            }
          ]
        })
      }
    }
    
    // 如果是群消息
    if (event.message_type === 'group') {
      await api.send_group_msg({
        group_id: event.group_id,
        message: [
          {
            type: 'text',
            data: {
              text: '收到你的群消息了！'
            }
          }
        ]
      })
    }
  })

  // 连接
  await api.connect()
}

main().catch(console.error)
