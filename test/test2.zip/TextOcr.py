import requests

def ocr_image(image_path, api_key):
    """
    使用 OCR.space API 识别图片中的文字
    
    Args:
        image_path: 图片路径
        api_key: OCR.space API密钥
    """
    url = "https://api.ocr.space/parse/image"
    
    # 准备文件和参数
    files = {
        'file': open(image_path, 'rb')
    }
    
    headers = {
        'apikey': api_key,
    }
    
    payload = {
        'language': 'chs',  # 支持中文识别
        'isOverlayRequired': True,
        'detectOrientation': True,
        'OCREngine': 2,  # 使用更准确的OCR引擎
    }
    
    try:
        response = requests.post(url, headers=headers, files=files, data=payload)
        print(f"响应状态码：{response.status_code}")
        print(f"响应内容：{response.text}")
        
        if response.status_code == 200:
            result = response.json()
            if result["OCRExitCode"] == 1:
                parsed_text = result["ParsedResults"][0]["ParsedText"]
                print("\n识别成功！")
                print("识别结果：", parsed_text)
            else:
                print("识别失败：", result.get("ErrorMessage", "未知错误"))
        else:
            print(f"请求失败，状态码：{response.status_code}")
            
    except Exception as e:
        print(f"发生错误：{str(e)}")
    
if __name__ == "__main__":
    image_path = "test.png"
    api_key = "K87108387888957"  # 需要替换成你的API密钥
    
    ocr_image(image_path, api_key)
