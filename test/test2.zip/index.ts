import { NCWebsocketApi } from '../src/NCWebsocketApi'
import dotenv from 'dotenv'
import fetch from 'node-fetch'
import * as fs from 'fs'
import * as path from 'path'
import { fileURLToPath } from 'url'

// 获取当前文件的目录路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 加载环境变量
dotenv.config()

// 创建图片保存目录
const SAVE_DIR = path.join(__dirname, 'received_images')
if (!fs.existsSync(SAVE_DIR)) {
  fs.mkdirSync(SAVE_DIR, { recursive: true })
}

async function saveImage(url: string, filename: string): Promise<string> {
  const response = await fetch(url)
  const arrayBuffer = await response.arrayBuffer()
  const buffer = Buffer.from(arrayBuffer)
  const savePath = path.join(SAVE_DIR, filename)
  fs.writeFileSync(savePath, buffer)
  return savePath
}

async function main() {
  const api = new NCWebsocketApi({
    protocol: 'ws',
    host: process.env.WS_HOST ?? '',
    port: Number(process.env.WS_PORT),
    accessToken: process.env.ACCESS_TOKEN
  })

  // 连接成功事件
  api.on('meta_event', event => {
    if (event.meta_event_type === 'lifecycle') {
      console.log('连接成功！')
    }
  })

  // 接收消息事件
  api.on('message', async event => {
    console.log('收到消息：', event)
    
    if (event.message_type === 'private') {
      // 检查是否是图片消息
      if (event.message[0]?.type === 'image') {
        const imageData = event.message[0].data
        const imageUrl = imageData.url
        const fileName = imageData.file // 原始文件名
        const fileId = imageData.file_id // 文件ID
        const fileUnique = imageData.file_unique // 文件唯一标识
        const fileSize = imageData.file_size // 文件大小
        
        try {
          // 保存图片
          const timestamp = new Date().getTime()
          const saveFileName = `${timestamp}_${fileUnique}.png`
          const savePath = await saveImage(imageUrl, saveFileName)
          
          // 回复消息
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: `我收到了你的图片：\n` +
                        `原始文件名：${fileName}\n` +
                        `文件ID：${fileId}\n` +
                        `文件唯一标识：${fileUnique}\n` +
                        `文件大小：${fileSize} 字节\n` +
                        `已保存到：${savePath}\n\n` +
                        `这是你发送的图片：\n`
                }
              },
              {
                type: 'image',
                data: {
                  file: imageUrl
                }
              }
            ]
          })
        } catch (error) {
          console.error('保存图片失败：', error)
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: '保存图片时发生错误！'
                }
              }
            ]
          })
        }
      } else {
        // 普通文本消息回复
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '收到你的消息了，宣传码是：R2DPTZ7Rz，每日一次，多了无效'
              }
            }
          ]
        })
      }
    }
    
    // 如果是群消息
    if (event.message_type === 'group') {
      await api.send_group_msg({
        group_id: event.group_id,
        message: [
          {
            type: 'text',
            data: {
              text: '收到你的群消息了！'
            }
          }
        ]
      })
    }
  })

  // 连接
  await api.connect()
}

main().catch(console.error)
