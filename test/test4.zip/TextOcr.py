import requests
import argparse
import json
import sys
from io import BytesIO

# 设置标准输出编码为UTF-8
sys.stdout.reconfigure(encoding='utf-8')

def ocr_image(image_source, api_key, is_url=False):
    """
    使用 OCR.space API 识别图片中的文字
    """
    url = "https://api.ocr.space/parse/image"
    
    headers = {
        'apikey': api_key,
    }
    
    payload = {
        'language': 'chs',
        'isOverlayRequired': True,
        'detectOrientation': True,
        'OCREngine': 2,
        'scale': True,
        'detectCheckbox': False,
    }
    
    try:
        if is_url:
            payload['url'] = image_source
            response = requests.post(url, headers=headers, data=payload)
        else:
            files = {'file': open(image_source, 'rb')}
            response = requests.post(url, headers=headers, files=files, data=payload)
        
        print(f"DEBUG: API响应状态码: {response.status_code}", file=sys.stderr)
        
        if response.status_code == 200:
            result = response.json()
            print(f"DEBUG: API原始响应: {result}", file=sys.stderr)
            
            # 检查配额限制错误
            if "ErrorMessage" in result:
                error_msg = str(result["ErrorMessage"])
                if "exceeded" in error_msg.lower() or "limit" in error_msg.lower():
                    print(json.dumps({"error": "API_LIMIT_EXCEEDED"}, ensure_ascii=False))
                    return
            
            if result["OCRExitCode"] == 1:
                parsed_text = result["ParsedResults"][0]["ParsedText"]
                print(f"DEBUG: 识别文本: {parsed_text}", file=sys.stderr)
                
                result_json = json.dumps(
                    {"text": parsed_text}, 
                    ensure_ascii=False, 
                    indent=2
                )
                print(result_json)
                return
        
        print(json.dumps({"error": "OCR识别失败"}, ensure_ascii=False))
            
    except Exception as e:
        print(json.dumps({"error": f"OCR识别错误：{str(e)}"}, ensure_ascii=False))

def check_quota(api_key):
    """
    检查 API key 的使用配额
    """
    url = "https://api.ocr.space/parse/image"
    headers = {
        'apikey': api_key,
    }
    
    try:
        # 使用一个1x1像素的透明图片来测试API
        test_image = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII="
        
        payload = {
            'language': 'eng',
            'base64Image': test_image,
            'OCREngine': 2,
            'filetype': 'PNG'
        }
        
        response = requests.post(url, headers=headers, data=payload)
        result = response.json()
        
        print(f"DEBUG: 配额检查响应: {result}", file=sys.stderr)
        
        if "ErrorMessage" in result:
            error_msg = str(result["ErrorMessage"])
            print(f"DEBUG: 错误信息: {error_msg}", file=sys.stderr)
            
            # 检查是否包含使用次数信息
            if any(word in error_msg.lower() for word in ['used', 'limit', 'quota', 'remaining']):
                import re
                # 尝试匹配不同格式的使用次数信息
                patterns = [
                    r'used (\d+)[^\d]*(\d+)',  # "used X of Y"
                    r'(\d+)[^\d]*requests[^\d]*(\d+)',  # "X requests out of Y"
                    r'remaining[^\d]*(\d+)[^\d]*(\d+)',  # "remaining X out of Y"
                ]
                
                for pattern in patterns:
                    matches = re.findall(pattern, error_msg, re.IGNORECASE)
                    if matches:
                        used, total = map(int, matches[0])
                        return {
                            "used": used,
                            "remaining": total - used,
                            "status": "超出限制" if used >= total else "正常",
                            "total": total,
                            "message": error_msg  # 添加原始错误信息以便调试
                        }
            
            # 检查是否超出限制
            if "exceeded" in error_msg.lower():
                return {
                    "used": 25000,
                    "remaining": 0,
                    "status": "超出限制",
                    "total": 25000,
                    "message": error_msg
                }
            
            # 如果有其他错误信息
            return {
                "status": "错误",
                "used": "未知",
                "remaining": "未知",
                "total": 25000,
                "message": error_msg
            }
        
        # 如果请求成功，说明API正常
        return {
            "status": "正常",
            "used": "至少1次",  # 因为我们刚刚成功使用了一次
            "remaining": "未知",
            "total": 25000,
            "message": "API工作正常"
        }
            
    except Exception as e:
        print(f"DEBUG: 检查配额时出错: {str(e)}", file=sys.stderr)
        return {
            "status": f"检查失败: {str(e)}",
            "used": "未知",
            "remaining": "未知",
            "total": 25000,
            "message": str(e)
        }

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='OCR图片识别')
    parser.add_argument('--image', help='图片路径或URL')
    parser.add_argument('--api_key', required=True, help='OCR.space API密钥')
    parser.add_argument('--url', action='store_true', help='是否是URL')
    parser.add_argument('--check_quota', action='store_true', help='检查配额')
    
    args = parser.parse_args()
    
    if args.check_quota:
        quota = check_quota(args.api_key)
        print(json.dumps(quota, ensure_ascii=False))
    elif args.image:
        ocr_image(args.image, args.api_key, args.url)
