export class OCRKeyManager {
  private keys: string[] = []
  private currentIndex: number = 0
  
  constructor(initialKeys: string[]) {
    this.keys = initialKeys
  }

  public getCurrentKey(): string {
    const key = this.keys[this.currentIndex]
    // 轮询到下一个key
    this.currentIndex = (this.currentIndex + 1) % this.keys.length
    return key
  }

  public getAllKeys(): string[] {
    return this.keys
  }
} 