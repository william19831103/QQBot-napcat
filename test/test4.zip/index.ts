import { NCWebsocketApi } from '../src/NCWebsocketApi'
import dotenv from 'dotenv'
import fetch from 'node-fetch'
import * as fs from 'fs'
import * as path from 'path'
import { fileURLToPath } from 'url'
import { spawn } from 'child_process'
import { tmpdir } from 'os'
import { OCRKeyManager } from './OCRKeyManager'

// 获取当前文件的目录路径
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

// 加载环境变量
dotenv.config()

// 初始化 OCR Key 管理器，只需要传入3个key
const ocrKeyManager = new OCRKeyManager([
  'K87108387888957',
  'K89499185488957',
  'K82081561288957'
])

// OCR文字识别函数
async function ocrImage(imageUrl: string): Promise<string> {
  const tempFile = path.join(tmpdir(), `ocr_temp_${Date.now()}.png`)
  
  try {
    const response = await fetch(imageUrl)
    const arrayBuffer = await response.arrayBuffer()
    const buffer = Buffer.from(arrayBuffer)
    fs.writeFileSync(tempFile, buffer)
    
    // 获取当前可用的 API Key
    const apiKey = ocrKeyManager.getCurrentKey()
    
    return new Promise((resolve, reject) => {
      const pythonProcess = spawn('python', [
        path.join(__dirname, 'TextOcr.py'),
        '--image', tempFile,
        '--api_key', apiKey
      ], {
        env: { ...process.env, PYTHONIOENCODING: 'utf-8' }
      })

      let result = ''

      pythonProcess.stdout.on('data', (data) => {
        result += data.toString('utf-8')
      })

      pythonProcess.on('close', (code) => {
        try {
          fs.unlinkSync(tempFile)
        } catch (e) {
          console.error('删除临时文件失败:', e)
        }

        if (code !== 0) {
          reject(new Error('OCR识别失败'))
        } else {
          try {
            const jsonResult = JSON.parse(result.trim())
            if (jsonResult.error) {
              reject(new Error(jsonResult.error))
            } else {
              resolve(jsonResult.text)
            }
          } catch (e) {
            reject(new Error('解析OCR结果失败'))
          }
        }
      })
    })
  } catch (error) {
    if (fs.existsSync(tempFile)) {
      fs.unlinkSync(tempFile)
    }
    throw error
  }
}

async function main() {
  const api = new NCWebsocketApi({
    protocol: 'ws',
    host: process.env.WS_HOST ?? '',
    port: Number(process.env.WS_PORT),
    accessToken: process.env.ACCESS_TOKEN
  })

  // 连接成功事件
  api.on('meta_event', event => {
    if (event.meta_event_type === 'lifecycle') {
      console.log('连接成功！')
    }
  })

  // 接收消息事件
  api.on('message', async event => {
    console.log('收到消息：', event)
    
    if (event.message_type === 'private') {
      // 检查是否是图片消息
      if (event.message[0]?.type === 'image') {
        const imageUrl = event.message[0].data.url
        
        try {
          // 进行OCR识别
          const ocrResult = await ocrImage(imageUrl)
          
          // 回复消息
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: `OCR识别结果：\n${ocrResult}\n\n这是你发送的图片：\n`
                }
              },
              {
                type: 'image',
                data: {
                  file: imageUrl
                }
              }
            ]
          })
        } catch (error) {
          console.error('处理图片失败：', error)
          await api.send_private_msg({
            user_id: event.user_id,
            message: [
              {
                type: 'text',
                data: {
                  text: '处理图片时发生错误！'
                }
              }
            ]
          })
        }
      } else {
        // 普通文本消息回复
        await api.send_private_msg({
          user_id: event.user_id,
          message: [
            {
              type: 'text',
              data: {
                text: '收到你的消息了，宣传码是：R2DPTZ7Rz，每日一次，多了无效'
              }
            }
          ]
        })
      }
    }
    
    // 如果是群消息
    if (event.message_type === 'group') {
      await api.send_group_msg({
        group_id: event.group_id,
        message: [
          {
            type: 'text',
            data: {
              text: '收到你的群消息了！'
            }
          }
        ]
      })
    }
  })

  // 连接
  await api.connect()
}

main().catch(console.error)
